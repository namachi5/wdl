import pandas as pd
import joblib

# Load dataset
df = pd.read_csv("healthcare_dataset.csv")

# Validate required columns
required_columns = {'symptoms', 'disease', 'specialist', 'medicine', 'usage', 'side_effects', 'health_tips'}
if not required_columns.issubset(df.columns):
    raise KeyError(f"Dataset must contain the columns: {', '.join(required_columns)}")

# Convert symptoms column to a list format
df['symptoms'] = df['symptoms'].apply(lambda x: x.split('|') if isinstance(x, str) else [])

# Save preprocessed data
joblib.dump(df, "healthcare_model.pkl")

print("Healthcare model saved successfully!")
