from flask import Flask, render_template, request, jsonify
import pandas as pd
import joblib

app = Flask(__name__)

# Load preprocessed dataset
df = joblib.load("healthcare_model.pkl")

@app.route('/')
def home():
    return render_template("index.html", health_tips=df["health_tips"].dropna().unique())

@app.route('/diagnose', methods=['POST'])
def diagnose():
    data = request.get_json()
    symptoms = data.get("symptoms", [])
    symptoms = [s.strip().lower() for s in symptoms]  # Convert to lowercase for matching

    print("User Symptoms:", symptoms)  # Debugging

    matched_diseases = []
    for _, row in df.iterrows():
        disease_symptoms = row['symptoms']
        if any(sym in disease_symptoms for sym in symptoms):
            matched_diseases.append({
                "disease": row['disease'],
                "specialist": row['specialist']
            })

    print("Matched Diseases:", matched_diseases)  # Debugging

    if not matched_diseases:
        return jsonify({"error": "No matching disease found."}), 404

    return jsonify({"diagnoses": matched_diseases})

@app.route('/doctor', methods=['GET'])
def get_doctor_recommendation():
    specialists = df["specialist"].dropna().unique().tolist()
    return jsonify({"specialists": specialists})

@app.route('/medicine', methods=['POST'])
def get_medicine_info():
    data = request.get_json()
    medicine_name = data.get("medicine", "").strip().lower()

    matched_medicine = df[df["medicine"].str.lower() == medicine_name]
    if matched_medicine.empty:
        return jsonify({"error": "No medicine found."}), 404

    medicine_info = matched_medicine.iloc[0].to_dict()
    return jsonify({
        "medicine": medicine_info["medicine"],
        "usage": medicine_info["usage"],
        "side_effects": medicine_info["side_effects"]
    })

@app.route('/visualization', methods=['GET'])
def generate_visualization():
    disease_counts = df["disease"].value_counts().to_dict()
    return jsonify({"predictions": disease_counts})

if __name__ == "__main__":
    app.run(debug=True)
