function getPrediction() {
    let hours = document.getElementById("hours_studied").value;
    let grades = document.getElementById("previous_grades").value;
    let attendance = document.getElementById("attendance").value;

    fetch('/predict', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ hours_studied: hours, previous_grades: grades, attendance: attendance })
    })
    .then(response => response.json())
    .then(data => {
        document.getElementById("predicted_grade").innerText = data.predicted_grade;
        document.getElementById("course_recommendation").innerText = data.course_recommendation;
        updateChart(data.predicted_grade);
    });
}

function updateChart(predictedGrade) {
    let ctx = document.getElementById('performanceChart').getContext('2d');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ['Predicted Grade'],
            datasets: [{
                label: 'Grade Prediction',
                data: [predictedGrade],
                backgroundColor: 'rgba(54, 162, 235, 0.6)'
            }]
        }
    });
}
