from flask import Flask, request, render_template, jsonify
import pickle
import pandas as pd
from sklearn.cluster import KMeans

app = Flask(__name__)

# Load the trained model and encoders
with open("model.pkl", "rb") as f:
    model, label_encoders = pickle.load(f)

# Load dataset for clustering
df = pd.read_csv("sample_customer_data.csv")

# Encode categorical features for clustering
for col in ['Region', 'Product_Category']:
    df[col] = label_encoders[col].transform(df[col])

# Apply K-Means for customer segmentation
kmeans = KMeans(n_clusters=3, random_state=42)
df["Cluster"] = kmeans.fit_predict(df[['Spending_Score', 'Age']])

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/predict", methods=["POST"])
def predict():
    data = request.json
    df_input = pd.DataFrame([data])

    for col in ['Region', 'Product_Category']:
        df_input[col] = label_encoders[col].transform([data[col]])[0]

    prediction = model.predict(df_input)[0]
    return jsonify({"prediction": int(prediction)})

@app.route("/segmentation")
def segmentation():
    cluster_counts = df["Cluster"].value_counts().to_dict()
    return jsonify(cluster_counts)

if __name__ == "__main__":
    app.run(debug=True)
