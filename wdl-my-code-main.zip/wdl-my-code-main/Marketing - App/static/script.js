document.getElementById("predictionForm").addEventListener("submit", function(event) {
    event.preventDefault();

    let age = document.getElementById("age").value;
    let region = document.getElementById("region").value;
    let productCategory = document.getElementById("productCategory").value;
    let spendingScore = document.getElementById("spendingScore").value;

    fetch("/predict", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ 
            Age: age, 
            Region: region, 
            Product_Category: productCategory, 
            Spending_Score: spendingScore 
        })
    })
    .then(response => response.json())
    .then(data => {
        let resultText = data.prediction === 1 ? "Likely to Churn" : "Not Likely to Churn";
        document.getElementById("predictionResult").innerText = resultText;
    })
    .catch(error => console.error("Error:", error));
});

// Fetch segmentation data and render the chart
function loadSegmentationChart() {
    fetch("/segmentation")
    .then(response => response.json())
    .then(data => {
        let ctx = document.getElementById("segmentationChart").getContext("2d");

        new Chart(ctx, {
            type: "pie",
            data: {
                labels: Object.keys(data).map(cluster => `Cluster ${cluster}`),
                datasets: [{
                    label: "Customer Segments",
                    data: Object.values(data),
                    backgroundColor: ["#FF6384", "#36A2EB", "#FFCE56"],
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                layout: {
                    padding: 10
                }
            }
        });
    })
    .catch(error => console.error("Error loading chart:", error));
}

// Load chart when the page loads
window.onload = loadSegmentationChart;
