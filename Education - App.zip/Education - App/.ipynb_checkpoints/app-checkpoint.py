from flask import Flask, request, jsonify, render_template
import joblib
import numpy as np

app = Flask(__name__)

# Load trained model & scaler
model = joblib.load("student_performance_model.pkl")
scaler = joblib.load("scaler.pkl")

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    try:
        data = request.json
        
        # Only include features that were used during training (match scaler input)
        features = np.array([[  
            data['hours_studied'],
            data['previous_grades'],
            data['attendance']
        ]])

        # Standardize input
        features_scaled = scaler.transform(features)

        # Predict final grade
        prediction = model.predict(features_scaled)[0]

        return jsonify({'final_grade_prediction': round(prediction, 2)})

    except Exception as e:
        return jsonify({'error': str(e)})

if __name__ == '__main__':
    app.run(debug=True)
